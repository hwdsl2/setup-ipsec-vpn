/*
 * Placeholder.  Please do not put #defines here!
 *
 * At one point ports defined macros in both both
 * ports/$(PORT)/include/sysdep.h and mk/defaults/$(PORT).mk.  That's
 * all gone. Instead all macros are defined in mk/defaults/$(PORT).mk
 * and then passed in via the command line.
 *
 * This file remains as a placeholder.  At some point in the future,
 * it can be replaced with a generated sysdep.h file.
 */
